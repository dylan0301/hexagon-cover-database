## Scope

Describe the mathematical or expository change and list every active theorem,
proof-package object, or generated artifact affected.

## Proof ownership

- [ ] Every new universal statement has a theorem whose hypotheses match its
      full quantified domain.
- [ ] Geometry-to-parameter bridges are used only for domain membership and
      objective identities.
- [ ] No proof status was upgraded without a status-bearing proof source.

## Verification

- [ ] `python tools/generate_active_dependency_graph.py --check`
- [ ] `python tools/generate_proof_manifest.py --check`
- [ ] `python tools/proof_lint.py`
- [ ] exact Strategy 4 certificate replay
- [ ] Strategy 2 Lean statement build
- [ ] deterministic paper and supplement build
- [ ] PDF layout check

Do not merge proof-bearing changes while the required workflow is red.
